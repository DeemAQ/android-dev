package com.example.movies.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.movies.Interactor
import com.example.movies.R
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    lateinit var gridLayoutManager: GridLayoutManager
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: RecyclerViewAdapter
    var page = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(main_toolbar)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.setHasFixedSize(true)

        adapter = RecyclerViewAdapter(this, mutableListOf())
        recyclerView.adapter = adapter
        gridLayoutManager = GridLayoutManager(this, 2)
        recyclerView.layoutManager = gridLayoutManager
        getPopular()

//        recyclerView.addOnScrollListener()

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (!recyclerView.canScrollVertically(1)) {
                    ++page
                    getPopular()
                }
            }
        })
    }

    private fun getPopular() {
        Interactor().getMovies(page).observe(this, { moviesList ->
            adapter.notifyChange(moviesList)
        })
    }

    private fun getTopRated() {
        Interactor().getTopRated(page).observe(this, { moviesList ->
            adapter.notifyChange(moviesList)
        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        main_toolbar.inflateMenu(R.menu.sort_by)
        val tr = menu.findItem(R.id.menuSortTopRating)
        tr.setOnMenuItemClickListener {
            getTopRated()
            true
        }

        val pop = menu.findItem(R.id.menuSortPop)
        tr.setOnMenuItemClickListener {
            getPopular()
            true
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.list -> {
                /*If you wish to open new activity and close this one
                 startNewActivity();*/
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}