package com.example.movies.api

import com.example.movies.data.ApiResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiInterface {
    @GET("3/movie/popular?")
    fun getPopular(@Query("api_key") api_key: String,
                   @Query("&page") page_num: Int): Call<ApiResponse>

    @GET("3/movie/top_rated?")
    fun getTopRated(@Query("api_key") api_key: String,
                   @Query("&page") page_num: Int): Call<ApiResponse>
}