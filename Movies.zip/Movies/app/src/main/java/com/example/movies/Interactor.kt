package com.example.movies

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.movies.api.ApiClient
import com.example.movies.data.ApiResponse
import com.example.movies.data.Movie
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Interactor {


    fun check(response: Response<ApiResponse>): Boolean {
        val responseBody = response.body()
        return responseBody.page != responseBody.total_pages
    }

    // Show all popular movies
    fun getMovies(page_num: Int): LiveData<MutableList<Movie>> {
        val data = MutableLiveData<MutableList<Movie>>()



        ApiClient.getPopular(page_num).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (!check(response))
                    data.postValue(null)
                else {
                    val responseBody = response.body()
                    data.postValue(responseBody.results)
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                data.postValue(null)
                Log.i("Interactor", "On Failure" + t.message)
            }
        })
        return data
    }

    fun getTopRated(page_num: Int): LiveData<MutableList<Movie>> {
        val data = MutableLiveData<MutableList<Movie>>()

        ApiClient.getTopRated(page_num).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (!check(response))
                    data.postValue(null)
                else {
                    val responseBody = response.body()
                    data.postValue(responseBody.results)
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                data.postValue(null)
                Log.i("Interactor", "On Failure" + t.message)
            }
        })
        return data
    }
}