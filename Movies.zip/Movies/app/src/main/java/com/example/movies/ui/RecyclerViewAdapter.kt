package com.example.movies.ui

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.movies.BASE_IMG_URL
import com.example.movies.R
import com.example.movies.data.Movie
import com.squareup.picasso.Picasso
import org.w3c.dom.CharacterData


class RecyclerViewAdapter(val context: Context, val movies: MutableList<Movie>) :
    PagingDataAdapter<Movie, RecyclerViewAdapter.ViewHolder>(DiffUtilCallBack()) {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val movie_image: ImageView

        init {
            movie_image = itemView.findViewById(R.id.movie_img)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, MovieDetails::class.java)
                val movie = movies[adapterPosition]
                intent.putExtra("Title", movie.original_title)
                intent.putExtra("Release Date", movie.release_date)
                intent.putExtra("Rating", movie.vote_average)
                intent.putExtra("Synopsis", movie.overview)
                intent.putExtra("Poster", movie.poster_path)
                intent.putExtra("Action Bar", movie.title)
                itemView.context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.movie_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val picasso = Picasso.get()
        // to load the image:
        if (movies[position].poster_path.isNullOrEmpty()) {
            picasso.load(R.drawable.poster_placeholder).into(holder.movie_image)
        } else {
            picasso.load(BASE_IMG_URL + movies[position].poster_path)
                .placeholder(R.drawable.poster_placeholder)
                .into(holder.movie_image)
        }
    }

    override fun getItemCount(): Int = movies.size

    fun notifyChange(movies_list: List<Movie>) {

        movies.clear()
        movies.addAll(movies_list)
        notifyDataSetChanged()
    }

    class DiffUtilCallBack: DiffUtil.ItemCallback<Movie>() {
        override fun areItemsTheSame(oldItem: Movie, newItem: Movie): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Movie, newItem: Movie): Boolean {
            return oldItem.id == newItem.id &&
                    oldItem.original_title.equals(newItem.original_title, ignoreCase = true)
        }

    }
}