package com.example.movies

const val BASE_IMG_URL = "http://image.tmdb.org/t/p/w185"
const val BASE_URL_API = "http://api.themoviedb.org/"