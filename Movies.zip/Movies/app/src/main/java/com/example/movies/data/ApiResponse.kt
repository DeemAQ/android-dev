package com.example.movies.data

data class ApiResponse (
    val page: Int,
    val results: MutableList<Movie>,
    val total_pages: Int,
    val total_results: Int
        )