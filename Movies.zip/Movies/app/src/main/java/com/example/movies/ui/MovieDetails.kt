package com.example.movies.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.movies.BASE_IMG_URL
import com.example.movies.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.movie_details.*


class MovieDetails : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.movie_details)
        setSupportActionBar(toolbar)

        movie_title.text = intent.getStringExtra("Title")
        val poster = intent.getStringExtra("Poster")
        movie_rating.text = intent.getDoubleExtra("Rating", 0.0).toString() + " / 10"
        movie_release_date.text = intent.getStringExtra("Release Date")
        movie_synopsis.text = intent.getStringExtra("Synopsis")
        val actionBar = intent.getStringExtra("Action Bar")
        toolbar.title = actionBar

        val picasso = Picasso.get()
        if (poster.isNullOrEmpty()) {
            picasso.load(R.drawable.poster_placeholder).into(movie_poster)
        } else {
            picasso.load(BASE_IMG_URL + poster)
                .placeholder(R.drawable.poster_placeholder)
                .into(movie_poster)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        toolbar.inflateMenu(R.menu.back_button)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.getItemId()) {
            R.id.back_btn -> {
                onBackPressed()
                /*If you wish to open new activity and close this one
                 startNewActivity();*/
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}
