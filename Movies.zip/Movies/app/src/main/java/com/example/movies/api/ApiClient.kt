package com.example.movies.api

import com.example.movies.BASE_URL_API
import com.example.movies.data.ApiResponse
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {
    private val api: ApiInterface

    init {
        val okHttp = OkHttpClient()
        val retrofit = Retrofit.Builder().baseUrl(BASE_URL_API)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttp).build()
        api = retrofit.create(ApiInterface::class.java)
    }

    fun getTopRated(page_num: Int): Call<ApiResponse> {
        return api.getTopRated("6301fd7f032134a1800fde6f6a27d702", page_num)
    }

    fun getPopular(page_num: Int): Call<ApiResponse> {
        return api.getPopular("6301fd7f032134a1800fde6f6a27d702", page_num)
    }
}