package com.example.colormyview

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setListeners()
    }

    private fun setListeners() {
        val clickableViews: List<View> = listOf(red_btn, green_btn, yellow_btn, blue_btn, bg)

        for (item in clickableViews) {
            item.setOnClickListener { makeColored(it) }
        }
    }

    @SuppressLint("ResourceAsColor")
    private fun makeColored(view: View ) {
        when (view.id) {
            R.id.red_btn -> box_one_txt.setBackgroundColor(resources.getColor(R.color.red))
            R.id.green_btn -> box_two_txt.setBackgroundColor(resources.getColor(R.color.green))
            R.id.yellow_btn -> box_three_txt.setBackgroundColor(resources.getColor(R.color.yellow))
            R.id.blue_btn -> box_four_txt.setBackgroundColor(resources.getColor(R.color.blue))
            else -> view.setBackgroundColor(resources.getColor(R.color.accent_color))
        }
    }
}